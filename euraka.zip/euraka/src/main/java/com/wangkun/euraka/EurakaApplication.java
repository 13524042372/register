package com.wangkun.euraka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurakaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurakaApplication.class, args);
	}
}
